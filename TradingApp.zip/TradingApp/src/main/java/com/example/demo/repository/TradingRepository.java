package com.example.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.trading;

@Repository
public interface TradingRepository extends MongoRepository<trading, String> {
	
	List<trading> findByBuyerName(String buyerName);

	List<trading> findBySellerName(String sellerName);

	List<trading> findByStockName(String stockName);

	List<trading> findByTradeDate(String tradeDate);
	
	List<trading> findByStockPrice(String stockPrice);
	
}