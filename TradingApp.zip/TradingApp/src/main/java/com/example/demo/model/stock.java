package com.example.demo.model;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "stock")
public class stock {

	private String partyName;
	private String tradeType;
	private String stockName;
	private String stockPrice;
	private String createdDate;
}
