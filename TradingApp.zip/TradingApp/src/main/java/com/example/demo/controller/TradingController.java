package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.stock;
import com.example.demo.model.trading;
import com.example.demo.repository.StockRepository;
import com.example.demo.repository.TradingRepository;

@RestController
@RequestMapping(value = "/trade", produces = "application/json")
public class TradingController {

	private StockRepository stockRepository;
	private TradingRepository tradingRepository;

	@Autowired
	public TradingController(StockRepository stockRepository, TradingRepository tradingRepository) {
		this.stockRepository = stockRepository;
		this.tradingRepository = tradingRepository;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
	public void createTrade(@RequestBody stock stockDetails) {
		List<stock> availableStocks = null;
		trading trading = null;
		String timestamp = new SimpleDateFormat("yyyy.mm.dd.HH.mm.ss").format(new Date());
		if (stockDetails.getTradeType() == "BUY") {
			availableStocks = stockRepository.findByStockNameAndStockPriceAndTradeType(stockDetails.getStockName(),
					stockDetails.getStockPrice(), "SELL");
			if (!availableStocks.isEmpty()) {
				stock stockAvailable = availableStocks.get(0);
				trading = trading.builder().buyerName(stockDetails.getPartyName())
						.sellerName(stockAvailable.getPartyName()).stockName(stockAvailable.getStockName())
						.tradeDate(timestamp).stockPrice(stockAvailable.getStockPrice()).build();
				tradingRepository.save(trading);
				stockRepository.delete(stockAvailable);
			} else {
				stockRepository.save(stockDetails);
			}
		} else {
			availableStocks = stockRepository.findByStockNameAndStockPriceAndTradeType(stockDetails.getStockName(),
					stockDetails.getStockPrice(), "BUY");
			if (!availableStocks.isEmpty()) {
				stock stockAvailable = availableStocks.get(0);
				trading = trading.builder().buyerName(stockAvailable.getPartyName())
						.sellerName(stockDetails.getPartyName()).stockName(stockAvailable.getStockName())
						.tradeDate(timestamp).stockPrice(stockAvailable.getStockPrice()).build();
				tradingRepository.save(trading);
				stockRepository.delete(stockAvailable);
			} else {
				stockRepository.save(stockDetails);
			}
		}

	}

	@RequestMapping(method = RequestMethod.GET, value = "/getTradingDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<trading> getTradingDetails(@RequestParam String stockName, @RequestParam String stockPrice,
			@RequestParam String tradeDate, @RequestParam String partyName) {
		List<trading> tradingList = null;
		if (Strings.isNotBlank(stockName)) {
			tradingList = tradingRepository.findByStockName(stockName);
		} else if (Strings.isNotBlank(stockPrice)) {
			tradingList = tradingRepository.findByStockPrice(stockPrice);
		} else if (Strings.isNotBlank(partyName)) {
			tradingList = tradingRepository.findBySellerName(partyName);
		} else {
			tradingList = tradingRepository.findByTradeDate(tradeDate);
		}
		return tradingList;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/getStockDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<stock> getStockDetails(@RequestParam String stockName, @RequestParam String stockPrice) {
		List<stock> stockList = null;
		if (Strings.isNotBlank(stockName)) {
			stockList = stockRepository.findByStockName(stockName);
		} else {
			stockList = stockRepository.findByStockPrice(stockPrice);
		}
		return stockList;
	}
}
