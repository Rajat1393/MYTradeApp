package com.example.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.stock;

@Repository
public interface StockRepository extends MongoRepository<stock, String> {
	List<stock> findByStockName(String stockName);

	List<stock> findByStockPrice(String stockPrice);
	
	List<stock> findByStockNameAndStockPrice(String stockName,String stockPrice);

	List<stock> findByStockNameAndStockPriceAndTradeType(String stockName,String stockPrice,String tradeType);
}